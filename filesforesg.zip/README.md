# ESG Scorecard — Corporate CSR Evaluation Tool

A structured, interactive evaluation framework for assessing corporate sustainability claims, identifying greenwashing behaviors, and comparing ESG disclosure quality across firms.

Built as the tangible deliverable for the capstone research project:
**"Corporate Social Responsibility, ESG Disclosure, and Greenwashing"**
Andover High School Senior Capstone, 2025–2026 | Arjun Nair

---

## Live Demo

Deploy via GitHub Pages: `Settings > Pages > Deploy from main branch`

The site will be live at `https://yourusername.github.io/esg-scorecard`

---

## What It Does

The scorecard evaluates a company across five categories drawn directly from the research findings:

| Category | What It Measures |
|---|---|
| ESG Disclosure Scope | CDP, GRI, TCFD, ESRS, PRI coverage |
| Emissions Reporting | Scope 1, 2, and 3 completeness + net-zero targets |
| Third-Party Verification | Independent audits, ratings, coalition membership |
| Greenwashing Risk | Lyon & Montgomery (2015) typology: omission, abandoned commitments, incomplete disclosure |
| Stakeholder Trust | Proxy voting support, supplier codes, board oversight |

Each question is scored Yes / Partial / No with weighted points. The total score out of 100 generates one of four verdicts:

- **Credible Commitment** (80+)
- **Partial Commitment** (60–79)
- **Weak Commitment** (40–59)
- **Critical Deficiency** (below 40)

Greenwashing risk flags auto-generate based on specific answer patterns, referencing the research typology by name.

---

## Preloaded Examples

The scorecard includes preset data for the three case study companies:

- **TJX Companies** — Low CSR engagement, greenwashing through omission
- **Liberty Mutual Insurance** — Moderate CSR engagement, incomplete disclosure
- **State Street Corporation** — High CSR engagement, abandoned commitments (CA100+ withdrawal, Feb 2024)

---

## Theoretical Framework

This tool is grounded in the following academic sources:

- Carroll, A. B. (1979). A three-dimensional conceptual model of corporate performance. *Academy of Management Review*, 4(4), 497–505.
- Dahlsrud, A. (2008). How corporate social responsibility is defined. *Corporate Social Responsibility and Environmental Management*, 15(1), 1–13.
- Eccles, R. G., Ioannou, I., & Serafeim, G. (2014). The impact of corporate sustainability on organizational processes and performance. *Management Science*, 60(11), 2835–2857.
- Lyon, T. P., & Montgomery, A. W. (2015). The means and end of greenwash. *Organization & Environment*, 28(2), 223–249.

---

## How to Use

1. Enter the company name or click a preset
2. Answer each question: **Y** (Yes), **~** (Partial), **N** (No)
3. The total score, category breakdown, verdict, and greenwashing flags update in real time
4. Use alongside SEC filings, CDP disclosures, GRI reports, and TCFD reports for accurate scoring

---

## Setup

No build tools, no dependencies. Pure HTML, CSS, and JavaScript.

```bash
git clone https://github.com/yourusername/esg-scorecard
cd esg-scorecard
open index.html
```

To deploy on GitHub Pages:
1. Push the repo to GitHub
2. Go to `Settings > Pages`
3. Set source to `main` branch, root folder
4. Your site will be live within a few minutes

---

## Research Context

Primary research for this project included:
- Practitioner interview with Emily Albrecht, Sustainability Analyst at BNY Mellon (Scope 3 emissions, CDP/GRI/TCFD/ESRS frameworks)
- Observation session with Emma Toole, SC&O Senior Analyst at Accenture (supply chain ESG integration)

Secondary research spanned 23 citations across peer-reviewed journals, SEC EDGAR filings, and corporate ESG disclosures.
